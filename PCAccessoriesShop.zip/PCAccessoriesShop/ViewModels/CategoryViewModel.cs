﻿using System.ComponentModel.DataAnnotations;

namespace PCAccessoriesShop.ViewModels
{
    public class CategoryViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Моля, въведете име на категорията."), MaxLength(100)]
        [Display(Name = "Име на категория")]
        public string Name { get; set; } = null!;
    }

}
