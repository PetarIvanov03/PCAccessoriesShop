﻿using Microsoft.AspNetCore.Identity;

namespace PCAccessoriesShop.Models
{
    public class ApplicationUser : IdentityUser
    {

    }

}
